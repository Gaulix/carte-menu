let lien = document.querySelector(".lien");
let div = document.querySelector(".galerie");

	lien.addEventListener("mouseover",function() {
	div.style.opacity  = "0";
	
	
	
});
	lien.addEventListener("mouseout",function() {
	div.style.opacity  = "1";
	
});
