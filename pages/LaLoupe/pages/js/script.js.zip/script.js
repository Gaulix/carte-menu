$(document).ready(function() {
	 $('h2').hide();

    $('form').click(function() {
		
		
		
        $('h1').hide(3000,function(){
			
		$('form').fadeOut(2000,function(){
		$('img').fadeOut(2000,function(){
			
		
		
		$('body').css('background-color','white');
		$('h2').show('slow');
    });
  });
    
});

});

});
