let btn = document.querySelector(".button3");
let div = document.querySelector(".galerie");

	btn.addEventListener("mouseover",function() {
	div.style.opacity  = "0";
	
	
	
});
	btn.addEventListener("mouseout",function() {
	div.style.opacity  = "1";
	
});
