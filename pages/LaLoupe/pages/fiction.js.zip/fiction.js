


let oiseaumoqueur   = document.getElementById('oiseaumoqueur');
let burger     		= document.getElementById('burger');

	burger.addEventListener('click', function() {
    	this.classList.toggle('active');
   	oiseaumoqueur.classList.toggle('active');
	confetti();
});



let aurora   	= document.getElementById('aurora');
let burger2     = document.getElementById('burger2');

	burger2.addEventListener('click', function() {
    	this.classList.toggle('active');
  	aurora.classList.toggle('active');
	confetti();
});



let congres   	= document.getElementById('congres');
let burger3     = document.getElementById('burger3');

	burger3.addEventListener('click', function() {
    	this.classList.toggle('active');
 	 congres.classList.toggle('active');
	 confetti();
});



let errante   	= document.getElementById('errante');
let burger4     = document.getElementById('burger4');

	burger4.addEventListener('click', function() {
    	this.classList.toggle('active');
  	errante.classList.toggle('active');
	confetti();
});


let fournaise  	= document.getElementById('fournaise');
let burger5     = document.getElementById('burger5');

	burger5.addEventListener('click', function() {
    	this.classList.toggle('active');
  	fournaise.classList.toggle('active');
	confetti();
});



let toiledutemps  = document.getElementById('toiledutemps');
let burger6    	  = document.getElementById('burger6');

	burger6.addEventListener('click', function() {
    	this.classList.toggle('active');
  	toiledutemps.classList.toggle('active');
	confetti();
});



let justeatemps  = document.getElementById('justeatemps');
let burger7      = document.getElementById('burger7');

	burger7.addEventListener('click', function() {
    	this.classList.toggle('active');
  	justeatemps.classList.toggle('active');
	confetti();
});



let homme  		 = document.getElementById('homme');
let burger8      = document.getElementById('burger8');

	burger8.addEventListener('click', function() {
    	this.classList.toggle('active');
  	homme.classList.toggle('active');
	confetti();
});


let cielbrulant  = document.getElementById('cielbrulant');
let burger9      = document.getElementById('burger9');

	burger9.addEventListener('click', function() {
    	this.classList.toggle('active');
  	cielbrulant.classList.toggle('active');
	confetti();
});



let barrierementale	= document.getElementById('barrierementale');
let burger10        = document.getElementById('burger10');

	burger10.addEventListener('click', function() {
    	this.classList.toggle('active');
  	barrierementale.classList.toggle('active');
	confetti();
});


let deesse	 		= document.getElementById('deesse');
let burger11        = document.getElementById('burger11');

	burger11.addEventListener('click', function() {
    	this.classList.toggle('active');
  	deesse.classList.toggle('active');
	confetti();
});



let formule	 		= document.getElementById('formule');
let burger12        = document.getElementById('burger12');

	burger12.addEventListener('click', function() {
   	 this.classList.toggle('active');
  	formule.classList.toggle('active');
	confetti();
});


let gaia 		= document.getElementById('gaia');
let burger13        = document.getElementById('burger13');

	burger13.addEventListener('click', function() {
   	 this.classList.toggle('active');
  	gaia.classList.toggle('active');
	confetti();
});

let chants 		= document.getElementById('chants');
let burger14        = document.getElementById('burger14');

	burger14.addEventListener('click', function() {
   	 this.classList.toggle('active');
  	chants.classList.toggle('active');
	confetti();
});

let coeur		= document.getElementById('coeur');
let burger15        = document.getElementById('burger15');

	burger15.addEventListener('click', function() {
   	 this.classList.toggle('active');
  	coeur.classList.toggle('active');
	confetti();
});




let darwin		= document.getElementById('darwin');
let burger16        = document.getElementById('burger16');

	burger16.addEventListener('click', function() {
   	 this.classList.toggle('active');
  	darwin.classList.toggle('active');
	confetti();
});



let mathematiques		= document.getElementById('mathematiques');
let burger17       = document.getElementById('burger17');

	burger17.addEventListener('click', function() {
   	 this.classList.toggle('active');
  	mathematiques.classList.toggle('active');
	confetti();
});

let ogre		= document.getElementById('ogre');
let burger18        = document.getElementById('burger18');

	burger18.addEventListener('click', function() {
   	 this.classList.toggle('active');
  	ogre.classList.toggle('active');
	confetti();
});

let secret		= document.getElementById('secret');
let burger19        = document.getElementById('burger19');

	burger19.addEventListener('click', function() {
   	 this.classList.toggle('active');
  	secret.classList.toggle('active');
	confetti();
});

let inconnue		= document.getElementById('inconnue');
let burger20        = document.getElementById('burger20');

	burger20.addEventListener('click', function() {
   	 this.classList.toggle('active');
  	inconnue.classList.toggle('active');
	confetti();
});

let curie		= document.getElementById('curie');
let burger21        = document.getElementById('burger21');

	burger21.addEventListener('click', function() {
   	 this.classList.toggle('active');
  	curie.classList.toggle('active');
	confetti();
});

let museum		= document.getElementById('museum');
let burger22        = document.getElementById('burger22');

	burger22.addEventListener('click', function() {
   	 this.classList.toggle('active');
  	museum.classList.toggle('active');
	confetti();
});

let god	= document.getElementById('god');
let burger23        = document.getElementById('burger23');

	burger23.addEventListener('click', function() {
   	 this.classList.toggle('active');
  	god.classList.toggle('active');
	confetti();
});

let proie	= document.getElementById('proie');
let burger24        = document.getElementById('burger24');

	burger24.addEventListener('click', function() {
   	 this.classList.toggle('active');
  	proie.classList.toggle('active');
	confetti();
});

let evolution		= document.getElementById('evolution');
let burger25        = document.getElementById('burger25');

	burger25.addEventListener('click', function() {
   	 this.classList.toggle('active');
  	evolution.classList.toggle('active');
	confetti();
});

let baton		= document.getElementById('baton');
let burger26        = document.getElementById('burger26');

	burger26.addEventListener('click', function() {
   	 this.classList.toggle('active');
  	baton.classList.toggle('active');
	confetti();
});


let rama	= document.getElementById('rama');
let burger27        = document.getElementById('burger27');

	burger27.addEventListener('click', function() {
   	 this.classList.toggle('active');
  	rama.classList.toggle('active');
	confetti();
});


let pere		= document.getElementById('pere');
let burger28        = document.getElementById('burger28');

	burger28.addEventListener('click', function() {
   	 this.classList.toggle('active');
  	pere.classList.toggle('active');
	confetti();
});



let darkmater		= document.getElementById('darkmater');
let burger29        = document.getElementById('burger29');

	burger29.addEventListener('click', function() {
   	 this.classList.toggle('active');
  	darkmater.classList.toggle('active');
	confetti();
});





























































































